from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/home/kim/nanoclo-fortran')
binary=root/'build/optimized/nanoclo-fortran'
source=root/'_tmp/arena-large/good/mathlib.ndjson'
output=root/'_tmp/submission-memory'
output.mkdir(exist_ok=True)
def sha(p):
 with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
cgroup=Path('/sys/fs/cgroup')/Path('/proc/self/cgroup').read_text().strip().split('::',1)[1].lstrip('/')
def memory():
 return {p.name:p.read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events','memory.swap.peak','memory.current'] if (p:=cgroup/name).exists()}
record={'binary_sha256':sha(binary),'input_sha256':sha(source),'jobs':4,'cgroup':str(cgroup),'before':memory(),'command':[str(binary),'--jobs=4',str(source)],'OMP_STACKSIZE':os.environ.get('OMP_STACKSIZE'),'memory_limit_bytes':16000000000,'swap_limit_bytes':0}
assert record['before']['memory.max']=='16000000000'
assert record['before']['memory.swap.max']=='0'
t0=time.monotonic()
with (output/'stdout').open('w') as out,(output/'stderr').open('w') as err:
 r=subprocess.run(record['command'],stdout=out,stderr=err)
record.update(process_status=r.returncode,wall_seconds=time.monotonic()-t0,after=memory())
assert sha(binary)==record['binary_sha256']
(root/'docs/submission-memory.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
raise SystemExit(r.returncode)
